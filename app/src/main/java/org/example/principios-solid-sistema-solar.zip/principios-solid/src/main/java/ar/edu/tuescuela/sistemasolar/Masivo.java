package ar.edu.tuescuela.sistemasolar;

/**
 * ISP (Interface Segregation): interfaz chica, con lo mínimo indispensable.
 * Cualquier cuerpo celeste tiene masa, pero no todos necesitan más que esto.
 */
public interface Masivo {
    double getMasa();
}
