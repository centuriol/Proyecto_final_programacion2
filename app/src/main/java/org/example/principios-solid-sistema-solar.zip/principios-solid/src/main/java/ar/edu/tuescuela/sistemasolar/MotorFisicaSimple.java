package ar.edu.tuescuela.sistemasolar;

import java.util.List;

/**
 * SRP: esta clase solo calcula física, no dibuja ni gestiona el inventario.
 * (Implementación bien vaga a propósito, es solo de ejemplo).
 */
public class MotorFisicaSimple implements MotorFisica {
    @Override
    public void avanzarPaso(List<CuerpoCeleste> cuerpos) {
        for (CuerpoCeleste c : cuerpos) {
            // Acá iría el cálculo real de gravedad/órbitas.
            // Por ahora simulamos un pequeño movimiento de ejemplo:
            c.mover(c.getPosicionX() + 1, c.getPosicionY() + 1);
        }
    }
}
