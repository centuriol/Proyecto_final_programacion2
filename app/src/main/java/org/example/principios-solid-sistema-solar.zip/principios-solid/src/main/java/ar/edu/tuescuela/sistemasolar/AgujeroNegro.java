package ar.edu.tuescuela.sistemasolar;

/**
 * OCP (Open/Closed): agregamos este "desastre" nuevo sin tener que
 * modificar CuerpoCeleste, SistemaSolar ni ninguna clase existente.
 */
public class AgujeroNegro extends CuerpoCeleste {
    public AgujeroNegro(String nombre, double masa, double x, double y) {
        super(nombre, masa, x, y);
    }

    public void absorber(CuerpoCeleste victima) {
        System.out.println(getNombre() + " absorbió a " + victima.getNombre() + "!");
    }

    @Override
    public String describir() {
        return "Agujero negro " + getNombre() + " (masa: " + getMasa() + ")";
    }
}
