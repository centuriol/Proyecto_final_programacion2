package ar.edu.tuescuela.sistemasolar;

import java.util.List;

/**
 * DIP (Dependency Inversion): SistemaSolar no depende de una implementación
 * concreta de física, depende de esta interfaz. Mañana se puede cambiar
 * el cálculo (más simple, más realista, etc.) sin tocar SistemaSolar.
 */
public interface MotorFisica {
    void avanzarPaso(List<CuerpoCeleste> cuerpos);
}
