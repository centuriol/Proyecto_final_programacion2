package ar.edu.tuescuela.sistemasolar;

public class Main {
    public static void main(String[] args) {
        SistemaSolar sistema = new SistemaSolar(new MotorFisicaSimple());

        Estrella sol = new Estrella("Sol", 1000, 0, 0);
        Planeta tierra = new Planeta("Tierra", 10, 100, 0);
        AgujeroNegro agujero = new AgujeroNegro("Sagitario A*", 5000, 300, 300);

        // LSP (Liskov): todos entran a la lista como CuerpoCeleste,
        // sin importar que sean Estrella, Planeta o AgujeroNegro.
        // El sistema no necesita saber la subclase exacta para funcionar.
        sistema.agregarCuerpo(sol);
        sistema.agregarCuerpo(tierra);
        sistema.agregarCuerpo(agujero);

        // Solo el planeta implementa Civilizable, así que solo a él le pedimos esto.
        tierra.desarrollarCivilizacion();

        sistema.avanzarPaso();

        for (CuerpoCeleste c : sistema.getCuerpos()) {
            System.out.println(c.describir());
        }
    }
}
