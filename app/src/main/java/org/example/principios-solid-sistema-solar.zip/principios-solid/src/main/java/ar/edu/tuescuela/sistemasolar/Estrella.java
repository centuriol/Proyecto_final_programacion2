package ar.edu.tuescuela.sistemasolar;

public class Estrella extends CuerpoCeleste {
    public Estrella(String nombre, double masa, double x, double y) {
        super(nombre, masa, x, y);
    }

    @Override
    public String describir() {
        return "Estrella " + getNombre() + " (masa: " + getMasa() + ")";
    }
}
