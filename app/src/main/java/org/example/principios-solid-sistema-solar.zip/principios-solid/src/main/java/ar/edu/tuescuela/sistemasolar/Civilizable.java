package ar.edu.tuescuela.sistemasolar;

/**
 * ISP (Interface Segregation): NO todos los cuerpos celestes pueden tener
 * civilizaciones (un agujero negro no), así que esto va separado de
 * CuerpoCeleste en vez de meterlo en la clase base para todos.
 */
public interface Civilizable {
    void desarrollarCivilizacion();
}
