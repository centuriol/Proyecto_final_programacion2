# Principios SOLID — Ejemplo vago del Sistema Solar

Esqueleto mínimo (sin Gradle ni JavaFX, solo Java puro) para mostrar dónde
aparece cada principio SOLID. A propósito NO está completo ni optimizado:
la idea es que sirva de mapa conceptual, no de código final.

## Dónde está cada principio

- **S — Single Responsibility**
  `CuerpoCeleste` solo guarda datos. `MotorFisicaSimple` solo calcula física.
  `SistemaSolar` solo administra la colección. Nadie hace más de una cosa.

- **O — Open/Closed**
  `AgujeroNegro` se agregó como una clase nueva, extendiendo `CuerpoCeleste`,
  sin tener que modificar ninguna clase existente.

- **L — Liskov Substitution**
  En `Main.java`, `Estrella`, `Planeta` y `AgujeroNegro` se guardan todos
  como `CuerpoCeleste` en la misma lista, y `SistemaSolar` los trata a
  todos por igual sin romperse.

- **I — Interface Segregation**
  `Civilizable` está separado de `Masivo` porque no todos los cuerpos
  celestes pueden tener civilización (un agujero negro no).

- **D — Dependency Inversion**
  `SistemaSolar` recibe un `MotorFisica` (interfaz) por constructor,
  no crea uno propio. Se puede cambiar la implementación de física sin
  tocar `SistemaSolar`.

## Cómo correrlo

Es Java puro, sin Gradle. Basta con:

```bash
cd src/main/java
javac ar/edu/tuescuela/sistemasolar/*.java
java ar.edu.tuescuela.sistemasolar.Main
```

Esto es solo la base conceptual — el proyecto real va con Gradle + JavaFX,
tal como lo venimos armando en las otras conversaciones.
