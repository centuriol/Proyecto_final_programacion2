package ar.edu.tuescuela.sistemasolar;

public class Planeta extends CuerpoCeleste implements Civilizable {
    private boolean tieneCivilizacion = false;

    public Planeta(String nombre, double masa, double x, double y) {
        super(nombre, masa, x, y);
    }

    @Override
    public void desarrollarCivilizacion() {
        this.tieneCivilizacion = true;
        System.out.println(getNombre() + " ahora tiene una civilización.");
    }

    public boolean tieneCivilizacion() {
        return tieneCivilizacion;
    }

    @Override
    public String describir() {
        return "Planeta " + getNombre() + " (civilización: " + tieneCivilizacion + ")";
    }
}
