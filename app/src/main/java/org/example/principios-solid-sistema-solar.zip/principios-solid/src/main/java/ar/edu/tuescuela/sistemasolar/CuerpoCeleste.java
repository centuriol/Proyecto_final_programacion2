package ar.edu.tuescuela.sistemasolar;

/**
 * SRP (Single Responsibility): esta clase solo se encarga de guardar los
 * datos básicos de un cuerpo celeste (nombre, masa, posición). No dibuja,
 * no calcula física, no gestiona civilizaciones: eso vive en otras clases.
 */
public abstract class CuerpoCeleste implements Masivo {
    private final String nombre;
    private double masa;
    private double posicionX;
    private double posicionY;

    public CuerpoCeleste(String nombre, double masa, double posicionX, double posicionY) {
        this.nombre = nombre;
        this.masa = masa;
        this.posicionX = posicionX;
        this.posicionY = posicionY;
    }

    @Override
    public double getMasa() {
        return masa;
    }

    public void setMasa(double masa) {
        this.masa = masa;
    }

    public String getNombre() {
        return nombre;
    }

    public double getPosicionX() {
        return posicionX;
    }

    public double getPosicionY() {
        return posicionY;
    }

    public void mover(double nuevaX, double nuevaY) {
        this.posicionX = nuevaX;
        this.posicionY = nuevaY;
    }

    /**
     * Cada subclase describe qué es de forma distinta.
     * (Esto es lo que habilita el OCP y el LSP: se puede agregar un
     * cuerpo celeste nuevo sin tocar esta clase, y cualquier subclase
     * puede usarse donde se espera un CuerpoCeleste sin romper nada).
     */
    public abstract String describir();
}
