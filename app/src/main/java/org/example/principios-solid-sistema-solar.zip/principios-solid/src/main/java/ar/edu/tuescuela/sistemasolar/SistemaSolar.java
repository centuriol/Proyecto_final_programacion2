package ar.edu.tuescuela.sistemasolar;

import java.util.ArrayList;
import java.util.List;

/**
 * SRP: solo administra la lista de cuerpos celestes y dispara los pasos.
 * DIP: recibe el MotorFisica por constructor (inyección de dependencia),
 * no crea uno propio adentro. Así podés testear o cambiar el motor
 * sin tocar esta clase.
 */
public class SistemaSolar {
    private final List<CuerpoCeleste> cuerpos = new ArrayList<>();
    private final MotorFisica motorFisica;

    public SistemaSolar(MotorFisica motorFisica) {
        this.motorFisica = motorFisica;
    }

    public void agregarCuerpo(CuerpoCeleste cuerpo) {
        cuerpos.add(cuerpo);
    }

    public void avanzarPaso() {
        motorFisica.avanzarPaso(cuerpos);
    }

    public List<CuerpoCeleste> getCuerpos() {
        return cuerpos;
    }
}
